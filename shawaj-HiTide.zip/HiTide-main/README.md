# HiTide
TIDAL Installer for Raspberry Pi OS

Usage
```
curl -sSL https://raw.githubusercontent.com/shawaj/HiTide/main/install.sh | sudo bash
```
